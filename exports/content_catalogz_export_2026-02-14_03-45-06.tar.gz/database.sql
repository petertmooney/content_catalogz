-- Content Catalogz Database Export
-- Export Date: 2026-02-14 03:45:06

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


-- Table structure for table `activities`
DROP TABLE IF EXISTS `activities`;
CREATE TABLE `activities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `type` enum('call','email','meeting','note','task','quote_sent','invoice_sent','payment_received','other') NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text,
  `activity_date` datetime NOT NULL,
  `duration_minutes` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  KEY `idx_date` (`activity_date`),
  KEY `idx_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table `activities`
INSERT INTO `activities` VALUES ('3', '3', 'meeting', 'On-Site SEO Review', 'Visited their office to review current website and SEO issues. Identified major opportunities.', '2026-01-28 11:00:00', '120', '2026-02-08 01:25:38', NULL);
INSERT INTO `activities` VALUES ('4', '3', 'email', 'SEO Audit Report Delivered', 'Sent comprehensive SEO audit report with recommendations and pricing', '2026-02-03 09:30:00', NULL, '2026-02-08 01:25:38', NULL);
INSERT INTO `activities` VALUES ('5', '4', 'email', 'Initial Inquiry', 'Received inquiry via contact form about social media management', '2026-02-07 16:45:00', NULL, '2026-02-08 01:25:38', NULL);
INSERT INTO `activities` VALUES ('6', '6', 'call', 'Weekly Check-in', 'Reviewed newsletter analytics - 42% open rate, 12% click rate. Very pleased with results.', '2026-02-06 15:00:00', '20', '2026-02-08 01:25:38', NULL);
INSERT INTO `activities` VALUES ('7', '6', 'meeting', 'Menu Photography Session', 'Met at cafe to photograph new menu items for February newsletter', '2026-01-30 13:00:00', '90', '2026-02-08 01:25:38', NULL);
INSERT INTO `activities` VALUES ('8', '5', 'email', 'Final Deliverables', 'Delivered final blog posts and 3-month content calendar. Project completed.', '2026-01-25 11:20:00', NULL, '2026-02-08 01:25:38', NULL);
INSERT INTO `activities` VALUES ('9', '3', 'note', 'Client created from quote', 'Quote converted to active client. Status changed to In Progress.', '2026-02-08 01:31:23', NULL, '2026-02-08 01:31:23', '1');
INSERT INTO `activities` VALUES ('23', '8', 'note', 'Client created from quote', 'Quote converted to active client. Status changed to In Progress.', '2026-02-08 19:29:47', NULL, '2026-02-08 19:29:47', '2');
INSERT INTO `activities` VALUES ('24', '8', 'payment_received', 'Payment Received: £5.00', 'Payment of £5.00 received via bank_transfer.', '2026-02-08 12:00:00', '0', '2026-02-08 19:30:54', '2');
INSERT INTO `activities` VALUES ('25', '7', 'note', 'Client created from quote', 'Quote converted to active client. Status changed to In Progress.', '2026-02-08 20:52:23', NULL, '2026-02-08 20:52:23', '2');
INSERT INTO `activities` VALUES ('26', '8', 'email', 'Invoice INV-1771013132991 Emailed', 'Invoice sent to williampue@yahoo.co.uk. Total: £123.00, Paid: £5.00, Remaining: £118.00', '2026-02-13 20:05:37', '0', '2026-02-13 20:05:38', '4');
INSERT INTO `activities` VALUES ('27', '12', 'note', 'Initial Contact', 'Updated project status and next steps.', '2026-01-16 21:17:03', NULL, '2026-02-13 21:17:03', '5');
INSERT INTO `activities` VALUES ('28', '12', 'call', 'Status Update', 'Discussed pricing and payment terms.', '2026-01-23 21:17:03', NULL, '2026-02-13 21:17:03', '3');
INSERT INTO `activities` VALUES ('29', '14', 'meeting', 'Initial Contact', 'Sent detailed proposal via email.', '2026-01-20 21:17:03', NULL, '2026-02-13 21:17:03', '4');
INSERT INTO `activities` VALUES ('30', '19', 'email', 'Follow-up', 'Received positive feedback on proposal.', '2026-01-21 21:17:03', NULL, '2026-02-13 21:17:03', '4');
INSERT INTO `activities` VALUES ('31', '20', 'note', 'Status Update', 'Scheduled follow-up meeting.', '2026-02-07 21:17:03', NULL, '2026-02-13 21:17:03', '5');
INSERT INTO `activities` VALUES ('32', '20', 'email', 'Initial Contact', 'Provided technical specifications.', '2026-02-05 21:17:03', NULL, '2026-02-13 21:17:03', '1');
INSERT INTO `activities` VALUES ('33', '21', 'note', 'Initial Contact', 'Client requested timeline adjustment.', '2026-01-16 21:17:03', NULL, '2026-02-13 21:17:03', '1');
INSERT INTO `activities` VALUES ('34', '21', 'meeting', 'Feedback Received', 'Updated project status and next steps.', '2026-02-01 21:17:03', NULL, '2026-02-13 21:17:03', '3');
INSERT INTO `activities` VALUES ('35', '22', 'note', 'Status Update', 'Updated project status and next steps.', '2026-01-30 21:17:03', NULL, '2026-02-13 21:17:03', '3');
INSERT INTO `activities` VALUES ('36', '23', 'note', 'Status Update', 'Client approved project scope.', '2026-02-10 21:17:03', NULL, '2026-02-13 21:17:03', '2');
INSERT INTO `activities` VALUES ('37', '23', 'meeting', 'Initial Contact', 'Provided technical specifications.', '2026-01-15 21:17:03', NULL, '2026-02-13 21:17:03', '4');
INSERT INTO `activities` VALUES ('38', '24', 'meeting', 'Quote Sent', 'Discussed project requirements and timeline.', '2026-01-25 21:17:03', NULL, '2026-02-13 21:17:03', '2');
INSERT INTO `activities` VALUES ('39', '26', 'call', 'Feedback Received', 'Updated project status and next steps.', '2026-01-14 21:17:03', NULL, '2026-02-13 21:17:03', '4');
INSERT INTO `activities` VALUES ('40', '27', 'note', 'Feedback Received', 'Discussed pricing and payment terms.', '2026-01-26 21:17:03', NULL, '2026-02-13 21:17:03', '4');
INSERT INTO `activities` VALUES ('41', '30', 'meeting', 'Follow-up', 'Client approved project scope.', '2026-02-07 21:17:03', NULL, '2026-02-13 21:17:03', '2');
INSERT INTO `activities` VALUES ('42', '31', 'meeting', 'Status Update', 'Discussed pricing and payment terms.', '2026-01-19 21:17:03', NULL, '2026-02-13 21:17:03', '5');
INSERT INTO `activities` VALUES ('43', '33', 'meeting', 'Project Discussion', 'Sent detailed proposal via email.', '2026-02-08 21:17:03', NULL, '2026-02-13 21:17:03', '3');
INSERT INTO `activities` VALUES ('44', '35', 'call', 'Status Update', 'Received positive feedback on proposal.', '2026-01-27 21:17:03', NULL, '2026-02-13 21:17:03', '2');
INSERT INTO `activities` VALUES ('45', '35', 'email', 'Feedback Received', 'Received positive feedback on proposal.', '2026-01-22 21:17:03', NULL, '2026-02-13 21:17:03', '3');
INSERT INTO `activities` VALUES ('46', '36', 'call', 'Follow-up', 'Discussed pricing and payment terms.', '2026-01-28 21:17:03', NULL, '2026-02-13 21:17:03', '5');
INSERT INTO `activities` VALUES ('47', '36', 'call', 'Quote Sent', 'Client approved project scope.', '2026-01-15 21:17:03', NULL, '2026-02-13 21:17:03', '5');
INSERT INTO `activities` VALUES ('48', '23', 'email', 'Invoice INV-1771019987183 Emailed', 'Invoice sent to kedwards@hotmail.com. Total: £4275.00, Paid: £855.00, Remaining: £3420.00', '2026-02-13 21:59:50', '0', '2026-02-13 21:59:50', '2');
INSERT INTO `activities` VALUES ('49', '23', 'email', 'Invoice INV-1771020069945 Emailed', 'Invoice sent to kedwards@hotmail.com. Total: £4275.00, Paid: £855.00, Remaining: £3420.00', '2026-02-13 22:01:12', '0', '2026-02-13 22:01:13', '2');
INSERT INTO `activities` VALUES ('50', '21', 'email', 'Invoice INV-1771020579705 Emailed', 'Invoice sent to rphillips@email.com. Total: £2712.00, Paid: £0.00, Remaining: £2712.00', '2026-02-13 22:09:42', '0', '2026-02-13 22:09:42', '2');
INSERT INTO `activities` VALUES ('51', '21', 'email', 'Invoice INV-1771020593148 Emailed', 'Invoice sent to rphillips@email.com. Total: £2712.00, Paid: £0.00, Remaining: £2712.00', '2026-02-13 22:09:54', '0', '2026-02-13 22:09:55', '2');
INSERT INTO `activities` VALUES ('52', '29', 'email', 'Invoice INV-1771026662841 Emailed', 'Invoice sent to kelly.evans@business.co.uk. Total: £0.00, Paid: £3027.03, Remaining: £-3027.03', '2026-02-13 23:51:05', '0', '2026-02-13 23:51:06', '2');
INSERT INTO `activities` VALUES ('53', '21', 'invoice_sent', 'Invoice Generated: INV-2026-21-20260214', 'Invoice created with total £2,812.00', '2026-02-14 01:16:12', NULL, '2026-02-14 01:16:12', '2');
INSERT INTO `activities` VALUES ('54', '22', 'invoice_sent', 'Invoice Generated: INV-2026-22-1771031844412', 'Invoice created with total £1,180.00', '2026-02-14 01:17:25', NULL, '2026-02-14 01:17:25', '2');
INSERT INTO `activities` VALUES ('55', '16', 'note', 'Services Updated', 'New service(s) added: Performance Reports', '2026-02-14 01:40:37', NULL, '2026-02-14 01:40:37', '2');
INSERT INTO `activities` VALUES ('56', '34', 'note', 'Services Updated', 'New service(s) added: Weekly Check-Ins', '2026-02-14 01:41:25', NULL, '2026-02-14 01:41:25', '2');
INSERT INTO `activities` VALUES ('57', '34', 'invoice_sent', 'Invoice Generated: INV-2026-34-1771033310675', 'Invoice created with total £3,810.00', '2026-02-14 01:41:51', NULL, '2026-02-14 01:41:51', '2');
INSERT INTO `activities` VALUES ('58', '34', 'email', 'Invoice INV-1771033342451 Emailed', 'Invoice sent to nicoleroberts@yahoo.com. Total: £0.00, Paid: £4180.00, Remaining: £-4180.00', '2026-02-14 01:42:24', '0', '2026-02-14 01:42:25', '2');
INSERT INTO `activities` VALUES ('59', '19', 'note', 'Services Updated', 'New service(s) added: Copywriting', '2026-02-14 01:46:28', NULL, '2026-02-14 01:46:28', '2');
INSERT INTO `activities` VALUES ('60', '19', 'invoice_sent', 'Invoice Generated: INV-2026-19-1771033612452', 'Invoice created with total £11,865.00', '2026-02-14 01:46:53', NULL, '2026-02-14 01:46:53', '2');
INSERT INTO `activities` VALUES ('61', '36', 'note', 'Services Updated', 'New service(s) added: Social Media Audit', '2026-02-14 02:05:45', NULL, '2026-02-14 02:05:45', '2');
INSERT INTO `activities` VALUES ('62', '36', 'invoice_sent', 'Invoice Generated: INV-2026-36-1771034748792', 'Invoice created with total £1,784.00', '2026-02-14 02:05:49', NULL, '2026-02-14 02:05:49', '2');
INSERT INTO `activities` VALUES ('63', '16', 'invoice_sent', 'Invoice Generated: INV-2026-16-1771034792234', 'Invoice created with total £4,521.00', '2026-02-14 02:06:32', NULL, '2026-02-14 02:06:32', '2');
INSERT INTO `activities` VALUES ('64', '34', 'email', 'Invoice INV-1771034963290 Emailed', 'Invoice sent to nicoleroberts@yahoo.com. Total: £0.00, Paid: £4180.00, Remaining: £-4180.00', '2026-02-14 02:09:25', '0', '2026-02-14 02:09:26', '2');
INSERT INTO `activities` VALUES ('65', '29', 'note', 'Services Updated', 'New service(s) added: 1 to 1 focused session', '2026-02-14 02:31:38', NULL, '2026-02-14 02:31:38', '2');
INSERT INTO `activities` VALUES ('66', '29', 'invoice_sent', 'Invoice Generated: INV-2026-29-1771036517746', 'Invoice created with total £3,929.00', '2026-02-14 02:35:18', NULL, '2026-02-14 02:35:18', '2');
INSERT INTO `activities` VALUES ('67', '29', 'email', 'Invoice INV-1771036843067 Emailed', 'Invoice sent to kelly.evans@business.co.uk. Total: £3929.00, Paid: £3027.03, Remaining: £901.97', '2026-02-14 02:40:50', '0', '2026-02-14 02:40:51', '2');
INSERT INTO `activities` VALUES ('68', '29', 'invoice_sent', 'Invoice Generated: INV-2026-29-1771037943146', 'Invoice created with total £5,029.00', '2026-02-14 02:59:03', NULL, '2026-02-14 02:59:03', '2');
INSERT INTO `activities` VALUES ('69', '29', 'invoice_sent', 'Invoice Generated: INV-2026-29-1771038243187', 'Invoice created with total £1,100.00', '2026-02-14 03:04:04', NULL, '2026-02-14 03:04:04', '2');
INSERT INTO `activities` VALUES ('70', '37', 'invoice_sent', 'Invoice Generated: INV-2026-37-1771039665299', 'Invoice created with total £1,100.00', '2026-02-14 03:27:46', NULL, '2026-02-14 03:27:46', '2');
INSERT INTO `activities` VALUES ('71', '37', 'email', 'Invoice INV-1771039980548 Emailed', 'Invoice sent to abc@234.com. Total: £1.00, Paid: £0.00, Remaining: £1.00', '2026-02-14 03:33:02', '0', '2026-02-14 03:33:03', '2');


-- Table structure for table `client_notes`
DROP TABLE IF EXISTS `client_notes`;
CREATE TABLE `client_notes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `note_text` text NOT NULL,
  `is_important` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  KEY `idx_important` (`is_important`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table `client_notes`
INSERT INTO `client_notes` VALUES ('3', '3', 'James mentioned they are talking to 2 other agencies. Need to follow up quickly.', '1', '2026-02-08 01:26:25', '2026-02-08 01:26:25', NULL);
INSERT INTO `client_notes` VALUES ('4', '3', 'Website built on WordPress. Current rankings: page 3-4 for main keywords.', '0', '2026-02-08 01:26:25', '2026-02-08 01:26:25', NULL);
INSERT INTO `client_notes` VALUES ('5', '4', 'Very active on Instagram (5k followers). Looking to increase Facebook presence.', '0', '2026-02-08 01:26:25', '2026-02-08 01:26:25', NULL);
INSERT INTO `client_notes` VALUES ('6', '6', 'Super friendly and easy to work with. Always responds within 24 hours.', '0', '2026-02-08 01:26:25', '2026-02-08 01:26:25', NULL);
INSERT INTO `client_notes` VALUES ('7', '6', 'Newsletter goes out first Monday of each month. Deadline is Friday before.', '1', '2026-02-08 01:26:25', '2026-02-08 01:26:25', NULL);
INSERT INTO `client_notes` VALUES ('8', '5', 'Michael was very happy with results. Asked to keep in touch for future projects.', '0', '2026-02-08 01:26:25', '2026-02-08 01:26:25', NULL);
INSERT INTO `client_notes` VALUES ('13', '4', 'test', '1', '2026-02-08 01:38:19', '2026-02-08 01:38:19', '1');
INSERT INTO `client_notes` VALUES ('15', '8', 'test note', '1', '2026-02-08 19:30:27', '2026-02-08 19:30:27', '2');
INSERT INTO `client_notes` VALUES ('16', '29', 'this is a test', '1', '2026-02-14 02:33:59', '2026-02-14 02:33:59', '2');


-- Table structure for table `client_tags`
DROP TABLE IF EXISTS `client_tags`;
CREATE TABLE `client_tags` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `tag_name` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_client_tag` (`client_id`,`tag_name`),
  KEY `idx_client` (`client_id`),
  KEY `idx_tag` (`tag_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- Table structure for table `crm_settings`
DROP TABLE IF EXISTS `crm_settings`;
CREATE TABLE `crm_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lead_source_colors` text,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- Table structure for table `email_settings`
DROP TABLE IF EXISTS `email_settings`;
CREATE TABLE `email_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `smtp_host` varchar(255) DEFAULT NULL,
  `smtp_port` int DEFAULT NULL,
  `smtp_username` varchar(255) DEFAULT NULL,
  `smtp_password` varchar(255) DEFAULT NULL,
  `smtp_encryption` varchar(10) DEFAULT 'tls',
  `smtp_from_email` varchar(255) DEFAULT NULL,
  `smtp_from_name` varchar(255) DEFAULT NULL,
  `enable_notifications` tinyint(1) DEFAULT '0',
  `enable_auto_reply` tinyint(1) DEFAULT '0',
  `notification_email` varchar(255) DEFAULT NULL,
  `auto_reply_template` text,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- Table structure for table `invoice_services`
DROP TABLE IF EXISTS `invoice_services`;
CREATE TABLE `invoice_services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(10,2) DEFAULT '1.00',
  `unit_price` decimal(10,2) NOT NULL,
  `total_cost` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_invoice` (`invoice_id`),
  CONSTRAINT `invoice_services_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `invoice_services`
INSERT INTO `invoice_services` VALUES ('1', '2', 'Email Newsletter Design and Development', '1.00', '400.00', '400.00', '2026-02-13 20:16:03', '2026-02-13 20:16:03');
INSERT INTO `invoice_services` VALUES ('2', '2', 'Content Creation and Copywriting', '1.00', '200.00', '200.00', '2026-02-13 20:16:03', '2026-02-13 20:16:03');
INSERT INTO `invoice_services` VALUES ('3', '3', 'Blog Post Writing (6 articles)', '6.00', '300.00', '1800.00', '2026-02-13 20:16:03', '2026-02-13 20:16:03');
INSERT INTO `invoice_services` VALUES ('4', '3', '3-Month Content Calendar Creation', '1.00', '600.00', '600.00', '2026-02-13 20:16:03', '2026-02-13 20:16:03');
INSERT INTO `invoice_services` VALUES ('5', '22', 'Strategy Development', '1.00', '2550.00', '2550.00', '2026-02-14 01:09:05', '2026-02-14 01:09:05');
INSERT INTO `invoice_services` VALUES ('6', '22', 'Content Planning & Creation', '1.00', '279.00', '279.00', '2026-02-14 01:09:05', '2026-02-14 01:09:05');
INSERT INTO `invoice_services` VALUES ('7', '22', 'Content Planning & Creation', '1.00', '100.00', '100.00', '2026-02-14 01:09:05', '2026-02-14 01:09:05');
INSERT INTO `invoice_services` VALUES ('8', '25', 'Training Session', '1.00', '480.00', '480.00', '2026-02-14 01:17:25', '2026-02-14 01:17:25');
INSERT INTO `invoice_services` VALUES ('9', '25', 'Maintenance Package', '1.00', '600.00', '600.00', '2026-02-14 01:17:25', '2026-02-14 01:17:25');
INSERT INTO `invoice_services` VALUES ('10', '25', 'Performance Reports', '1.00', '100.00', '100.00', '2026-02-14 01:17:25', '2026-02-14 01:17:25');
INSERT INTO `invoice_services` VALUES ('11', '26', 'Email Marketing', '1.00', '410.00', '410.00', '2026-02-14 01:41:51', '2026-02-14 01:41:51');
INSERT INTO `invoice_services` VALUES ('12', '26', 'Video Production', '1.00', '3390.00', '3390.00', '2026-02-14 01:41:51', '2026-02-14 01:41:51');
INSERT INTO `invoice_services` VALUES ('13', '26', 'Weekly Check-Ins', '1.00', '10.00', '10.00', '2026-02-14 01:41:51', '2026-02-14 01:41:51');
INSERT INTO `invoice_services` VALUES ('14', '27', 'PPC Advertising', '1.00', '1425.00', '1425.00', '2026-02-14 01:46:53', '2026-02-14 01:46:53');
INSERT INTO `invoice_services` VALUES ('15', '27', 'Video Production', '1.00', '3330.00', '3330.00', '2026-02-14 01:46:53', '2026-02-14 01:46:53');
INSERT INTO `invoice_services` VALUES ('16', '27', 'E-commerce Setup', '1.00', '4410.00', '4410.00', '2026-02-14 01:46:53', '2026-02-14 01:46:53');
INSERT INTO `invoice_services` VALUES ('17', '27', 'Website Design', '1.00', '2500.00', '2500.00', '2026-02-14 01:46:53', '2026-02-14 01:46:53');
INSERT INTO `invoice_services` VALUES ('18', '27', 'Copywriting', '1.00', '200.00', '200.00', '2026-02-14 01:46:53', '2026-02-14 01:46:53');
INSERT INTO `invoice_services` VALUES ('19', '28', 'SEO Optimization', '1.00', '1284.00', '1284.00', '2026-02-14 02:05:49', '2026-02-14 02:05:49');
INSERT INTO `invoice_services` VALUES ('20', '28', 'Social Media Audit', '1.00', '500.00', '500.00', '2026-02-14 02:05:49', '2026-02-14 02:05:49');
INSERT INTO `invoice_services` VALUES ('21', '29', 'Consultation', '1.00', '336.00', '336.00', '2026-02-14 02:06:32', '2026-02-14 02:06:32');
INSERT INTO `invoice_services` VALUES ('22', '29', 'Email Marketing', '1.00', '520.00', '520.00', '2026-02-14 02:06:32', '2026-02-14 02:06:32');
INSERT INTO `invoice_services` VALUES ('23', '29', 'PPC Advertising', '1.00', '1800.00', '1800.00', '2026-02-14 02:06:32', '2026-02-14 02:06:32');
INSERT INTO `invoice_services` VALUES ('24', '29', 'Strategy Development', '1.00', '1665.00', '1665.00', '2026-02-14 02:06:32', '2026-02-14 02:06:32');
INSERT INTO `invoice_services` VALUES ('25', '29', 'Performance Reports', '1.00', '200.00', '200.00', '2026-02-14 02:06:32', '2026-02-14 02:06:32');
INSERT INTO `invoice_services` VALUES ('26', '31', 'Strategy Development', '1.00', '2550.00', '2550.00', '2026-02-14 02:35:18', '2026-02-14 02:35:18');
INSERT INTO `invoice_services` VALUES ('27', '31', 'Content Planning & Creation', '1.00', '279.00', '279.00', '2026-02-14 02:35:18', '2026-02-14 02:35:18');
INSERT INTO `invoice_services` VALUES ('28', '31', 'Content Planning & Creation', '1.00', '1000.00', '1000.00', '2026-02-14 02:35:18', '2026-02-14 02:35:18');
INSERT INTO `invoice_services` VALUES ('29', '31', '1 to 1 focused session', '1.00', '100.00', '100.00', '2026-02-14 02:35:18', '2026-02-14 02:35:18');
INSERT INTO `invoice_services` VALUES ('30', '32', 'Content Planning & Creation', '1.00', '1000.00', '1000.00', '2026-02-14 02:59:03', '2026-02-14 02:59:03');
INSERT INTO `invoice_services` VALUES ('31', '32', '1 to 1 focused session', '1.00', '100.00', '100.00', '2026-02-14 02:59:03', '2026-02-14 02:59:03');
INSERT INTO `invoice_services` VALUES ('32', '33', 'Strategy Development', '1.00', '2550.00', '2550.00', '2026-02-14 03:04:04', '2026-02-14 03:04:04');
INSERT INTO `invoice_services` VALUES ('33', '33', 'Content Planning & Creation', '1.00', '279.00', '279.00', '2026-02-14 03:04:04', '2026-02-14 03:04:04');
INSERT INTO `invoice_services` VALUES ('34', '33', 'Content Planning & Creation', '1.00', '1000.00', '1000.00', '2026-02-14 03:04:04', '2026-02-14 03:04:04');
INSERT INTO `invoice_services` VALUES ('35', '33', '1 to 1 focused session', '1.00', '100.00', '100.00', '2026-02-14 03:04:04', '2026-02-14 03:04:04');


-- Table structure for table `invoices`
DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `total_cost` decimal(10,2) DEFAULT '0.00',
  `total_paid` decimal(10,2) DEFAULT '0.00',
  `total_remaining` decimal(10,2) DEFAULT '0.00',
  `invoice_number` varchar(50) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('draft','sent','paid','overdue','cancelled') DEFAULT 'draft',
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL,
  `paid_date` date DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `idx_client` (`client_id`),
  KEY `idx_status` (`status`),
  KEY `idx_invoice_number` (`invoice_number`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table `invoices`
INSERT INTO `invoices` VALUES ('2', '6', '2026-01-31', '600.00', '600.00', '0.00', 'INV-2026-002', '600.00', 'overdue', '2026-01-31', '2026-02-28', '2026-02-01', 'Email Newsletter - January', '2026-02-08 01:27:09', '2026-02-08 22:25:23');
INSERT INTO `invoices` VALUES ('3', '5', '2026-01-25', '2400.00', '2400.00', '0.00', 'INV-2026-003', '2400.00', 'paid', '2026-01-25', '2026-02-25', '2026-01-26', 'Blog Posts (6 articles) + 3-Month Content Calendar', '2026-02-08 01:27:09', '2026-02-08 01:27:09');
INSERT INTO `invoices` VALUES ('5', '8', '2026-02-08', '123.00', '5.00', '118.00', 'INV-TEST-007', '123.00', 'overdue', '2026-02-08', '2026-03-10', NULL, 'test', '2026-02-08 20:24:34', '2026-02-08 22:22:41');
INSERT INTO `invoices` VALUES ('14', '8', '2026-02-09', '123.00', '5.00', '118.00', 'INV-2026-8-20260209', '123.00', 'sent', '2026-02-09', '2026-03-11', NULL, NULL, '2026-02-09 22:50:08', '2026-02-09 22:50:08');
INSERT INTO `invoices` VALUES ('15', '8', '2026-02-13', '123.00', '5.00', '118.00', 'INV-1770999179508', '123.00', 'sent', '2026-02-13', '2026-03-15', NULL, NULL, '2026-02-13 16:12:59', '2026-02-13 16:12:59');
INSERT INTO `invoices` VALUES ('16', '0', '2026-02-13', '0.00', '0.00', '0.00', 'INV-1771013426397', '0.00', 'sent', '2026-02-13', '2026-03-15', NULL, NULL, '2026-02-13 20:10:26', '2026-02-13 20:10:26');
INSERT INTO `invoices` VALUES ('17', '21', '2026-02-13', '2712.00', '0.00', '2712.00', 'INV-2026-21-20260213', '2712.00', 'sent', '2026-02-13', '2026-03-15', NULL, NULL, '2026-02-13 21:36:37', '2026-02-13 21:36:37');
INSERT INTO `invoices` VALUES ('18', '23', '2026-02-13', '4275.00', '855.00', '3420.00', 'INV-2026-23-20260213', '4275.00', 'sent', '2026-02-13', '2026-03-15', NULL, NULL, '2026-02-13 21:59:01', '2026-02-13 21:59:01');
INSERT INTO `invoices` VALUES ('19', '29', '2026-02-13', '2829.00', '3027.03', '-198.03', 'INV-2026-29-20260213', '2829.00', 'sent', '2026-02-13', '2026-03-15', NULL, NULL, '2026-02-13 22:08:49', '2026-02-13 22:08:49');
INSERT INTO `invoices` VALUES ('20', '29', '2026-02-14', '2829.00', '3027.03', '-198.03', 'INV-2026-29-20260214', '2829.00', 'sent', '2026-02-14', '2026-03-16', NULL, NULL, '2026-02-14 00:40:05', '2026-02-14 00:40:05');
INSERT INTO `invoices` VALUES ('22', '29', '2026-02-14', '2929.00', '3027.03', '-98.03', 'INV-2026-29-1771031344440', '2929.00', 'sent', '2026-02-14', '2026-03-16', NULL, NULL, '2026-02-14 01:09:05', '2026-02-14 01:09:05');
INSERT INTO `invoices` VALUES ('23', '21', '2026-02-14', '2812.00', '0.00', '2812.00', 'INV-2026-21-20260214', '2812.00', 'sent', '2026-02-14', '2026-03-16', NULL, NULL, '2026-02-14 01:16:12', '2026-02-14 01:16:12');
INSERT INTO `invoices` VALUES ('25', '22', '2026-02-14', '1180.00', '367.20', '812.80', 'INV-2026-22-1771031844412', '1180.00', 'sent', '2026-02-14', '2026-03-16', NULL, NULL, '2026-02-14 01:17:25', '2026-02-14 01:17:25');
INSERT INTO `invoices` VALUES ('26', '34', '2026-02-14', '3810.00', '4180.00', '-370.00', 'INV-2026-34-1771033310675', '3810.00', 'sent', '2026-02-14', '2026-03-16', NULL, NULL, '2026-02-14 01:41:51', '2026-02-14 01:41:51');
INSERT INTO `invoices` VALUES ('27', '19', '2026-02-14', '11865.00', '12364.90', '-499.90', 'INV-2026-19-1771033612452', '11865.00', 'sent', '2026-02-14', '2026-03-16', NULL, NULL, '2026-02-14 01:46:53', '2026-02-14 01:46:53');
INSERT INTO `invoices` VALUES ('28', '36', '2026-02-14', '1784.00', '0.00', '1784.00', 'INV-2026-36-1771034748792', '1784.00', 'sent', '2026-02-14', '2026-03-16', NULL, NULL, '2026-02-14 02:05:49', '2026-02-14 02:05:49');
INSERT INTO `invoices` VALUES ('29', '16', '2026-02-14', '4521.00', '4839.52', '-318.52', 'INV-2026-16-1771034792234', '4521.00', 'sent', '2026-02-14', '2026-03-16', NULL, NULL, '2026-02-14 02:06:32', '2026-02-14 02:06:32');
INSERT INTO `invoices` VALUES ('31', '29', '2026-02-14', '3929.00', '3027.03', '901.97', 'INV-2026-29-1771036517746', '3929.00', 'sent', '2026-02-14', '2026-03-16', NULL, NULL, '2026-02-14 02:35:18', '2026-02-14 02:35:18');
INSERT INTO `invoices` VALUES ('32', '29', '2026-02-14', '5029.00', '3027.03', '2001.97', 'INV-2026-29-1771037943146', '5029.00', 'sent', '2026-02-14', '2026-03-16', NULL, NULL, '2026-02-14 02:59:03', '2026-02-14 02:59:03');
INSERT INTO `invoices` VALUES ('33', '29', '2026-02-14', '1100.00', '3027.03', '-1927.03', 'INV-2026-29-1771038243187', '1100.00', 'sent', '2026-02-14', '2026-03-16', NULL, NULL, '2026-02-14 03:04:04', '2026-02-14 03:04:04');


-- Table structure for table `pages`
DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `page_type` varchar(50) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'draft',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table `pages`
INSERT INTO `pages` VALUES ('1', 'Welcome to Content Catalogz', 'welcome', '<h1>Welcome to Content Catalogz</h1><p>This is a sample page created from the database to demonstrate the CMS functionality.</p>', 'general', 'published', '2026-02-08 01:03:41', '2026-02-08 01:03:41');


-- Table structure for table `quotes`
DROP TABLE IF EXISTS `quotes`;
CREATE TABLE `quotes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `company` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address_street` varchar(255) DEFAULT NULL,
  `address_line2` varchar(255) DEFAULT NULL,
  `address_city` varchar(100) DEFAULT NULL,
  `address_county` varchar(100) DEFAULT NULL,
  `address_postcode` varchar(20) DEFAULT NULL,
  `address_country` varchar(100) DEFAULT 'United Kingdom',
  `services` json DEFAULT NULL,
  `total_cost` decimal(10,2) DEFAULT '0.00',
  `total_paid` decimal(10,2) DEFAULT '0.00',
  `total_remaining` decimal(10,2) DEFAULT '0.00',
  `service` varchar(100) DEFAULT NULL,
  `message` text NOT NULL,
  `status` varchar(50) DEFAULT 'new',
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lead_source` varchar(100) DEFAULT NULL,
  `expected_value` decimal(10,2) DEFAULT NULL,
  `next_follow_up` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`),
  KEY `idx_status` (`status`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table `quotes`
INSERT INTO `quotes` VALUES ('3', 'James O\'Brien', NULL, NULL, 'james@digitalmarkets.ie', 'Digital Markets Ireland', '+353 21 456 7890', '12 Patrick Street', NULL, 'Cork', 'Cork', 'T12 X456', 'Ireland', '[]', '0.00', '0.00', '3200.00', 'SEO Optimization', 'Need to improve our search rankings for key industry terms. Currently on page 3-4 for most searches.', 'in_progress', 'Converting to active client - TEST', '2026-02-08 01:23:24', '2026-02-13 21:06:46', 'Website', NULL, NULL);
INSERT INTO `quotes` VALUES ('4', 'Emma Kelly', NULL, NULL, 'ekelly@greenleaf.ie', 'GreenLeaf Organics', '+353 91 234 567', '78 Shop Street', NULL, 'Galway', 'Galway', 'H91 F2X3', 'Ireland', '[{\"cost\": 200, \"name\": \"post management\"}]', '200.00', '0.00', '1800.00', 'Social Media Management', 'We need help managing our Instagram and Facebook. Looking for 3 posts per week plus stories.', 'in_progress', '', '2026-02-08 01:23:24', '2026-02-13 21:06:46', 'Website', NULL, NULL);
INSERT INTO `quotes` VALUES ('5', 'Michael Walsh', NULL, NULL, 'm.walsh@coastaldesigns.ie', 'Coastal Designs Studio', '+353 66 123 4567', '23 Main Street', NULL, 'Killarney', 'Kerry', 'V93 X2P5', 'Ireland', NULL, '2400.00', '2400.00', '0.00', 'Content Strategy', 'Starting a new blog and need help with content planning, keyword research, and initial articles.', 'completed', 'Project completed successfully. May return for ongoing work.', '2026-02-08 01:23:24', '2026-02-13 21:06:46', 'Website', NULL, NULL);
INSERT INTO `quotes` VALUES ('6', 'Lisa Brennan', NULL, NULL, 'lisa@westcoastcafe.ie', 'West Coast Cafe & Bistro', '+353 86 234 5678', '56 Quay Street', NULL, 'Galway', 'Galway', 'H91 E9K7', 'Ireland', NULL, '1200.00', '600.00', '600.00', 'Email Marketing', 'Want to start a monthly newsletter for our loyal customers. Need help with design and content.', 'in_progress', 'First newsletter sent last week. Customer very happy with results.', '2026-02-08 01:23:24', '2026-02-13 21:06:46', 'Website', NULL, NULL);
INSERT INTO `quotes` VALUES ('7', 'Peter Mooney', NULL, NULL, 'petertmooney@outlook.com', 'Moonweaver Designs', '+447930069190', '18 mountain view', 'Castlewellan', 'Newcastle', 'Down', 'BT31 9SG', 'United Kingdom', '[{\"cost\": 1231, \"name\": \"web\"}]', '1231.00', '0.00', '1231.00', 'starter-pack', 'this is a test', 'in_progress', 'this is a test note', '2026-02-08 03:30:43', '2026-02-13 21:06:46', 'Website', NULL, NULL);
INSERT INTO `quotes` VALUES ('8', 'William Pue', NULL, NULL, 'williampue@yahoo.co.uk', 'none', '1234567890', '', '', '', '', '', 'United Kingdom', '[{\"cost\": 123, \"name\": \"beta testing\"}]', '123.00', '5.00', '118.00', 'marketing', 'this is a test request', 'in_progress', '', '2026-02-08 19:29:06', '2026-02-13 21:06:46', 'Website', NULL, NULL);
INSERT INTO `quotes` VALUES ('9', 'Test Lead', NULL, NULL, 'test@example.com', 'ACME', '0123456789', NULL, NULL, NULL, NULL, NULL, 'United Kingdom', NULL, '0.00', '0.00', '0.00', 'Web Design', 'Test lead from curl', 'new', NULL, '2026-02-13 00:08:38', '2026-02-13 21:06:46', 'Website', NULL, NULL);
INSERT INTO `quotes` VALUES ('10', 'CLI Test', NULL, NULL, 'cli@example.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'United Kingdom', '[]', '0.00', '0.00', '0.00', 'test', 'testing crm fields', 'declined', '', '2026-02-13 01:23:20', '2026-02-13 20:25:20', 'Referral', '1234.56', '2026-03-01');
INSERT INTO `quotes` VALUES ('11', 'Beverly Edwards', 'Beverly', 'Edwards', 'beverly.edwards@business.co.uk', NULL, '0151 789 8990', '672 Finchley Road', NULL, 'Edinburgh', 'Derbyshire', 'VS00 8PJ', 'United Kingdom', '[{\"cost\": 752, \"name\": \"Social Media Marketing\"}, {\"cost\": 1425, \"name\": \"PPC Advertising\"}, {\"cost\": 2134, \"name\": \"CRM Setup\"}, {\"cost\": 5600, \"name\": \"Custom Development\"}]', '9911.00', '5153.72', '4757.28', NULL, 'General inquiry about services', 'cancelled', NULL, '2026-02-13 21:16:37', '2026-02-13 21:16:37', 'Website', NULL, NULL);
INSERT INTO `quotes` VALUES ('12', 'Elizabeth Nguyen', 'Elizabeth', 'Nguyen', 'enguyen@email.com', 'Graphic Design Hub', '0161 757 8703', '742 Finchley Road', NULL, 'Coventry', 'West Midlands', 'XL54 1OH', 'United Kingdom', '[{\"cost\": 430, \"name\": \"Email Marketing\"}]', '430.00', '111.80', '318.20', NULL, 'Initial inquiry about Email Marketing', 'cancelled', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Other', NULL, NULL);
INSERT INTO `quotes` VALUES ('13', 'Aaron Williams', 'Aaron', 'Williams', 'aaronwilliams@gmail.com', 'Creative Agency', '020 392 5382', '111 Dalston Lane', NULL, 'Belfast', 'West Yorkshire', 'EB08 1SW', 'United Kingdom', '[{\"cost\": 624, \"name\": \"Maintenance Package\"}]', '624.00', '723.84', '-99.84', NULL, 'General inquiry about services', 'new', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Website', NULL, NULL);
INSERT INTO `quotes` VALUES ('14', 'Billy Rogers', 'Billy', 'Rogers', 'brogers@outlook.com', 'Marketing Solutions', '0113 636 0436', '140 Kings Road', 'Flat 32', 'Wolverhampton', 'West Midlands', 'VJ28 0BF', 'United Kingdom', '[{\"cost\": 2820, \"name\": \"Video Production\"}, {\"cost\": 3885, \"name\": \"Website Development\"}]', '6705.00', '4291.20', '2413.80', NULL, 'General inquiry about services', 'cancelled', 'Requested a follow-up call next week.', '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Other', NULL, NULL);
INSERT INTO `quotes` VALUES ('15', 'Wayne Collins', 'Wayne', 'Collins', 'wcollins@business.co.uk', 'Marketing Experts', '0115 669 0572', '283 Baker Street', 'Flat 33', 'Hull', 'West Midlands', 'VR30 9IO', 'United Kingdom', '[{\"cost\": 1272, \"name\": \"SEO Optimization\"}, {\"cost\": 688, \"name\": \"Logo Design\"}, {\"cost\": 576, \"name\": \"Content Creation\"}]', '2536.00', '2536.00', '0.00', NULL, 'Initial inquiry about SEO Optimization, Logo Design, Content Creation', 'cancelled', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Email Marketing', NULL, NULL);
INSERT INTO `quotes` VALUES ('16', 'Melissa Lopez', 'Melissa', 'Lopez', 'melissa_lopez@company.com', '', '0113 384 2797', '806 Whitechapel Road', '', 'Leicester', 'West Midlands', 'MT54 8BQ', 'United Kingdom', '[{\"cost\": 336, \"name\": \"Consultation\"}, {\"cost\": 520, \"name\": \"Email Marketing\"}, {\"cost\": 1800, \"name\": \"PPC Advertising\"}, {\"cost\": 1665, \"name\": \"Strategy Development\"}, {\"cost\": 200, \"name\": \"Performance Reports\"}]', '4521.00', '4839.52', '-318.52', NULL, 'Initial inquiry about Consultation, Email Marketing, PPC Advertising, Strategy Development', 'new', 'Technical requirements need clarification.', '2026-02-13 21:17:03', '2026-02-14 01:40:37', 'Email Marketing', NULL, NULL);
INSERT INTO `quotes` VALUES ('17', 'Terry Collins', 'Terry', 'Collins', 'terry.collins@outlook.com', 'App Development', '0161 515 8349', '19 Hampstead High Street', 'Flat 5', 'London', 'Cardiff', 'KX50 2PI', 'United Kingdom', '[{\"cost\": 7760, \"name\": \"Mobile App Development\"}]', '7760.00', '2172.80', '5587.20', NULL, 'Initial inquiry about Mobile App Development', 'in_progress', 'Requested a follow-up call next week.', '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Website', NULL, NULL);
INSERT INTO `quotes` VALUES ('18', 'Donald Rodriguez', 'Donald', 'Rodriguez', 'donald.rodriguez@gmail.com', NULL, '0114 383 6593', '173 Church Road', NULL, 'Manchester', 'Glasgow City', 'JM88 7OC', 'United Kingdom', '[{\"cost\": 3450, \"name\": \"Video Production\"}, {\"cost\": 5600, \"name\": \"Custom Development\"}, {\"cost\": 3360, \"name\": \"Website Development\"}, {\"cost\": 664, \"name\": \"Social Media Marketing\"}]', '13074.00', '13727.70', '-653.70', NULL, 'General inquiry about services', 'in_progress', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Other', NULL, NULL);
INSERT INTO `quotes` VALUES ('19', 'Sean Kim', 'Sean', 'Kim', 'sean_kim@outlook.com', 'App Development', '020 898 7570', '759 Kentish Town Road', 'Flat 2', 'Leicester', 'Glasgow City', 'MS18 8SU', 'United Kingdom', '[{\"cost\": 1425, \"name\": \"PPC Advertising\"}, {\"cost\": 3330, \"name\": \"Video Production\"}, {\"cost\": 4410, \"name\": \"E-commerce Setup\"}, {\"cost\": 2500, \"name\": \"Website Design\"}, {\"cost\": 200, \"name\": \"Copywriting\"}]', '11865.00', '12364.90', '-499.90', NULL, 'Initial inquiry about PPC Advertising, Video Production, E-commerce Setup, Website Design', 'new', 'Looking for ongoing maintenance agreement.', '2026-02-13 21:17:03', '2026-02-14 01:46:28', 'Direct Contact', NULL, NULL);
INSERT INTO `quotes` VALUES ('20', 'Donna Thomas', 'Donna', 'Thomas', 'dthomas@business.co.uk', NULL, '0114 232 6038', '418 Old Street', NULL, 'Nottingham', 'Leicestershire', 'JY82 2VP', 'United Kingdom', '[{\"cost\": 552, \"name\": \"Content Creation\"}, {\"cost\": 333, \"name\": \"Consultation\"}, {\"cost\": 1764, \"name\": \"Brand Identity Design\"}, {\"cost\": 738, \"name\": \"Analytics Setup\"}]', '3387.00', '1659.63', '1727.37', NULL, 'Initial inquiry about Content Creation, Consultation, Brand Identity Design, Analytics Setup', 'new', 'Timeline is tight - expedited delivery needed.', '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Direct Contact', NULL, NULL);
INSERT INTO `quotes` VALUES ('21', 'Ryan Phillips', 'Ryan', 'Phillips', 'rphillips@email.com', NULL, '0113 612 2122', '31 Camden High Street', 'Flat 49', 'Leeds', 'Staffordshire', 'DZ40 4BP', 'United Kingdom', '[{\"cost\": 480, \"name\": \"Email Marketing\"}, {\"cost\": 288, \"name\": \"Consultation\"}, {\"cost\": 1944, \"name\": \"Brand Identity Design\"}, {\"cost\": 100, \"name\": \"Strategy Development\"}]', '2812.00', '0.00', '2812.00', NULL, 'General inquiry about services', 'in_progress', 'Multiple stakeholders involved in decision making.', '2026-02-13 21:17:03', '2026-02-14 01:16:01', 'Referral', NULL, NULL);
INSERT INTO `quotes` VALUES ('22', 'Andrew Carter', 'Andrew', 'Carter', 'acarter@gmail.com', 'Photography Studio', '0113 748 3017', '804 St John\'s Wood', 'Flat 23', 'Plymouth', 'Devon', 'GZ85 6TE', 'United Kingdom', '[{\"cost\": 480, \"name\": \"Training Session\"}, {\"cost\": 600, \"name\": \"Maintenance Package\"}, {\"cost\": 1000, \"name\": \"Performance Reports\"}]', '2080.00', '367.20', '1712.80', NULL, 'Initial inquiry about Training Session, Maintenance Package', 'new', 'Budget approved - ready to proceed.', '2026-02-13 21:17:03', '2026-02-14 02:29:41', 'Social Media', NULL, NULL);
INSERT INTO `quotes` VALUES ('23', 'Kelly Edwards', 'Kelly', 'Edwards', 'kedwards@hotmail.com', 'SEO Specialists', '0114 726 9417', '444 Victoria Road', '', 'Aberdeen', 'Staffordshire', 'HN27 3XG', 'United Kingdom', '[{\"cost\": 4275, \"name\": \"E-commerce Setup\"}, {\"cost\": 100, \"name\": \"Social Media Audit\"}, {\"cost\": 100, \"name\": \"1 to 1 focused session\"}]', '4475.00', '855.00', '3620.00', NULL, 'Initial inquiry about E-commerce Setup', 'completed', 'Requested a follow-up call next week.', '2026-02-13 21:17:03', '2026-02-14 01:20:46', 'Other', NULL, NULL);
INSERT INTO `quotes` VALUES ('24', 'Dennis Ward', 'Dennis', 'Ward', 'dennis.ward@email.com', 'Creative Collective', '0191 998 3887', '883 Baker Street', 'Flat 7', 'Bristol', 'City of Edinburgh', 'BS83 4ZR', 'United Kingdom', '[{\"cost\": 7360, \"name\": \"Mobile App Development\"}, {\"cost\": 3780, \"name\": \"E-commerce Setup\"}, {\"cost\": 4700, \"name\": \"Custom Development\"}, {\"cost\": 1458, \"name\": \"Brand Identity Design\"}]', '17298.00', '5881.32', '11416.68', NULL, 'Initial inquiry about Mobile App Development, E-commerce Setup, Custom Development, Brand Identity Design', 'completed', 'Budget constraints - need to discuss pricing.', '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Website', NULL, NULL);
INSERT INTO `quotes` VALUES ('25', 'Janet Ross', 'Janet', 'Ross', 'janet_ross@gmail.com', NULL, '0121 903 6150', '822 Camden High Street', 'Flat 41', 'Glasgow', 'Avon', 'SJ97 6RI', 'United Kingdom', '[{\"cost\": 642, \"name\": \"Content Creation\"}, {\"cost\": 3080, \"name\": \"Website Development\"}, {\"cost\": 672, \"name\": \"Social Media Marketing\"}, {\"cost\": 1320, \"name\": \"Photography\"}]', '5714.00', '3199.84', '2514.16', NULL, 'Initial inquiry about Content Creation, Website Development, Social Media Marketing, Photography', 'completed', 'Multiple stakeholders involved in decision making.', '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Direct Contact', NULL, NULL);
INSERT INTO `quotes` VALUES ('26', 'Tyler Evans', 'Tyler', 'Evans', 'tyler_evans@gmail.com', NULL, '0121 844 1701', '289 Portobello Road', NULL, 'Bristol', 'Greater Manchester', 'QD15 4XO', 'United Kingdom', '[{\"cost\": 624, \"name\": \"Maintenance Package\"}, {\"cost\": 1590, \"name\": \"PPC Advertising\"}, {\"cost\": 1638, \"name\": \"Brand Identity Design\"}, {\"cost\": 5400, \"name\": \"Custom Development\"}]', '9252.00', '2220.48', '7031.52', NULL, 'General inquiry about services', 'cancelled', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Social Media', NULL, NULL);
INSERT INTO `quotes` VALUES ('27', 'Wanda Ruiz', 'Wanda', 'Ruiz', 'wanda.ruiz@gmail.com', 'Marketing Solutions', '0113 680 9585', '739 Kings Road', '', 'Plymouth', 'Greater Manchester', 'JN50 5TG', 'United Kingdom', '[{\"cost\": 2610, \"name\": \"Video Production\"}, {\"cost\": 200, \"name\": \"Content Planning & Creation\"}]', '2810.00', '0.00', '2810.00', NULL, 'Initial inquiry about Video Production', 'completed', 'Strong focus on ROI and results.', '2026-02-13 21:17:03', '2026-02-14 01:22:20', 'Email Marketing', NULL, NULL);
INSERT INTO `quotes` VALUES ('28', 'Catherine Turner', 'Catherine', 'Turner', 'catherine.turner@yahoo.com', 'Design Studio', '0117 858 7523', '540 Kentish Town Road', 'Flat 21', 'Bradford', 'Aberdeen City', 'BO97 1FB', 'United Kingdom', '[{\"cost\": 2596, \"name\": \"CRM Setup\"}, {\"cost\": 636, \"name\": \"Maintenance Package\"}, {\"cost\": 4060, \"name\": \"Website Development\"}, {\"cost\": 2475, \"name\": \"Website Design\"}]', '9767.00', '11720.40', '-1953.40', NULL, 'General inquiry about services', 'completed', 'Previous experience with similar projects.', '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Email Marketing', NULL, NULL);
INSERT INTO `quotes` VALUES ('29', 'Kelly Evans', 'Kelly', 'Evans', 'kelly.evans@business.co.uk', 'Marketing Experts', '0116 498 1031', '206 Regent Street', '', 'Manchester', 'West Midlands', 'DU32 8BB', 'United Kingdom', '[{\"cost\": 2550, \"name\": \"Strategy Development\"}, {\"cost\": 279, \"name\": \"Content Planning & Creation\"}, {\"cost\": 1000, \"name\": \"Content Planning & Creation\"}, {\"cost\": 100, \"name\": \"1 to 1 focused session\"}]', '3929.00', '3027.03', '901.97', NULL, 'Initial inquiry about Video Production, Consultation', 'completed', 'Client has specific integration requirements.', '2026-02-13 21:17:03', '2026-02-14 02:31:38', 'Social Media', NULL, NULL);
INSERT INTO `quotes` VALUES ('30', 'Mildred Hughes', 'Mildred', 'Hughes', 'mildred_hughes@hotmail.com', 'Marketing Experts', '0191 273 5979', '578 Brick Lane', '', 'Wolverhampton', 'West Glamorgan', 'YM58 6FJ', 'United Kingdom', '[{\"cost\": 656, \"name\": \"Logo Design\"}, {\"cost\": 2760, \"name\": \"Video Production\"}, {\"cost\": 299, \"name\": \"1 to 1 focused session\"}]', '3715.00', '0.00', '3715.00', NULL, 'Initial inquiry about Logo Design, Video Production', 'completed', 'Requested a follow-up call next week.', '2026-02-13 21:17:03', '2026-02-14 01:31:19', 'Email Marketing', NULL, NULL);
INSERT INTO `quotes` VALUES ('31', 'Debra Carter', 'Debra', 'Carter', 'debracarter@email.com', 'E-commerce Solutions', '0114 250 8344', '355 Bond Street', NULL, 'London', 'Leicestershire', 'EW56 7OB', 'United Kingdom', '[{\"cost\": 2574, \"name\": \"CRM Setup\"}, {\"cost\": 360, \"name\": \"Consultation\"}]', '2934.00', '1085.58', '1848.42', NULL, 'General inquiry about services', 'new', 'Looking for ongoing maintenance agreement.', '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Social Media', NULL, NULL);
INSERT INTO `quotes` VALUES ('32', 'Kimberly Thompson', 'Kimberly', 'Thompson', 'kimberly.thompson@hotmail.com', 'Photography Studio', '0151 169 8119', '647 City Road', 'Flat 48', 'Nottingham', 'Greater Manchester', 'UX68 7LN', 'United Kingdom', '[{\"cost\": 714, \"name\": \"Maintenance Package\"}, {\"cost\": 9280, \"name\": \"Mobile App Development\"}, {\"cost\": 2625, \"name\": \"Website Design\"}]', '12619.00', '0.00', '12619.00', NULL, 'General inquiry about services', 'cancelled', 'Looking for ongoing maintenance agreement.', '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Email Marketing', NULL, NULL);
INSERT INTO `quotes` VALUES ('33', 'Jose Foster', 'Jose', 'Foster', 'jfoster@gmail.com', NULL, '020 683 0995', '156 Victoria Road', 'Flat 16', 'Derby', 'Merseyside', 'FH83 7LZ', 'United Kingdom', '[{\"cost\": 2550, \"name\": \"Video Production\"}, {\"cost\": 3395, \"name\": \"Website Development\"}, {\"cost\": 1416, \"name\": \"SEO Optimization\"}, {\"cost\": 1392, \"name\": \"Photography\"}]', '8753.00', '3238.61', '5514.39', NULL, 'General inquiry about services', 'cancelled', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Website', NULL, NULL);
INSERT INTO `quotes` VALUES ('34', 'Nicole Roberts', 'Nicole', 'Roberts', 'nicoleroberts@yahoo.com', 'Business Consulting', '020 259 4879', '815 High Street', 'Flat 26', 'Derby', 'Nottinghamshire', 'OU65 4ER', 'United Kingdom', '[{\"cost\": 410, \"name\": \"Email Marketing\"}, {\"cost\": 3390, \"name\": \"Video Production\"}, {\"cost\": 10, \"name\": \"Weekly Check-Ins\"}]', '3810.00', '4180.00', '-370.00', NULL, 'Initial inquiry about Email Marketing, Video Production', 'completed', 'Competitor analysis required before proceeding.', '2026-02-13 21:17:03', '2026-02-14 01:41:25', 'Direct Contact', NULL, NULL);
INSERT INTO `quotes` VALUES ('35', 'Jessica White', 'Jessica', 'White', 'jessica.white@email.com', NULL, '0114 517 7120', '257 Swiss Cottage', 'Flat 37', 'Newcastle', 'Dundee City', 'YK00 8CR', 'United Kingdom', '[{\"cost\": 5150, \"name\": \"Custom Development\"}, {\"cost\": 1515, \"name\": \"Strategy Development\"}, {\"cost\": 816, \"name\": \"Social Media Marketing\"}, {\"cost\": 590, \"name\": \"Email Marketing\"}]', '8071.00', '8958.81', '-887.81', NULL, 'General inquiry about services', 'in_progress', 'Looking for innovative solutions.', '2026-02-13 21:17:03', '2026-02-13 21:17:03', 'Social Media', NULL, NULL);
INSERT INTO `quotes` VALUES ('36', 'Brandon Perez', 'Brandon', 'Perez', 'brandonperez@gmail.com', '', '0116 703 4253', '867 Upper Street', 'Flat 44', 'Bristol', 'West Midlands', 'NM05 6IE', 'United Kingdom', '[{\"cost\": 1284, \"name\": \"SEO Optimization\"}, {\"cost\": 500, \"name\": \"Social Media Audit\"}]', '1784.00', '0.00', '1784.00', NULL, 'General inquiry about services', 'in_progress', 'Multiple stakeholders involved in decision making.', '2026-02-13 21:17:03', '2026-02-14 02:05:45', 'Website', NULL, NULL);
INSERT INTO `quotes` VALUES ('37', 'adb def', 'adb', 'def', 'abc@234.com', 'new nasty prick company', '+447903345678', '321 Mountainous viewable', 'Underworld', 'Helll', 'Satan Cpin', '', 'United Kingdom', NULL, '0.00', '0.00', '0.00', '', 'Manually added client', 'new', '', '2026-02-14 03:11:32', '2026-02-14 03:11:32', NULL, NULL, NULL);
INSERT INTO `quotes` VALUES ('38', 'adb def', 'adb', 'def', 'satanslovechild@hell.ubderworld', 'new nasty prick company', '+447903345678', '321 Mountainous viewable', 'Underworld', 'Helll', 'Satan County', '666 2344', 'United Kingdom', NULL, '0.00', '0.00', '0.00', 'starter-pack', 'another day another test', 'contacted', 'Customer is a time waster', '2026-02-14 03:15:47', '2026-02-14 03:15:47', NULL, NULL, NULL);


-- Table structure for table `tasks`
DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `client_id` int DEFAULT NULL,
  `assigned_to` int DEFAULT NULL,
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `status` enum('pending','in_progress','completed','cancelled') DEFAULT 'pending',
  `due_date` date DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`),
  KEY `idx_due_date` (`due_date`),
  KEY `idx_assigned` (`assigned_to`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table `tasks`
INSERT INTO `tasks` VALUES ('3', 'Follow up on SEO audit', 'Check if they received the report and answer questions', '3', NULL, 'high', 'pending', '2026-02-10', NULL, '2026-02-08 01:24:58', '2026-02-08 01:24:58', NULL);
INSERT INTO `tasks` VALUES ('5', 'Prepare February newsletter', 'Focus on Valentine\'s Day specials', '6', NULL, 'medium', 'in_progress', '2026-02-14', NULL, '2026-02-08 01:24:58', '2026-02-08 01:24:58', NULL);
INSERT INTO `tasks` VALUES ('6', 'Send feedback survey', 'Get testimonial for portfolio', '5', NULL, 'low', 'pending', '2026-02-20', NULL, '2026-02-08 01:24:58', '2026-02-08 01:24:58', NULL);
INSERT INTO `tasks` VALUES ('7', 'follow up', 'test', NULL, NULL, 'high', 'pending', '2026-02-15', NULL, '2026-02-08 01:49:09', '2026-02-08 01:49:09', '1');
INSERT INTO `tasks` VALUES ('8', 'urgent test task', 'test', '7', NULL, 'urgent', 'pending', '2026-02-20', NULL, '2026-02-13 12:15:11', '2026-02-13 12:15:11', '2');
INSERT INTO `tasks` VALUES ('9', 'Payment collection', 'Prepare comprehensive project proposal and pricing.', '14', '1', 'low', 'in_progress', '2026-02-16', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '3');
INSERT INTO `tasks` VALUES ('11', 'Requirements gathering', 'Gather detailed requirements and project specifications.', '14', '2', 'high', 'pending', '2026-03-06', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '5');
INSERT INTO `tasks` VALUES ('12', 'Initial consultation call', 'Set up social media accounts and profiles.', '15', '3', 'medium', 'pending', '2026-03-03', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '1');
INSERT INTO `tasks` VALUES ('13', 'Contract review', 'Process final payment and close project.', '15', '5', 'medium', 'completed', '2026-03-15', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '2');
INSERT INTO `tasks` VALUES ('14', 'Initial consultation call', 'Deliver final project files and documentation.', '17', '1', 'low', 'pending', '2026-03-10', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '3');
INSERT INTO `tasks` VALUES ('15', 'Client feedback review', 'Create initial design concepts and wireframes.', '17', '1', 'urgent', 'completed', '2026-03-05', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '4');
INSERT INTO `tasks` VALUES ('17', 'Payment collection', 'Create content for website and marketing materials.', '18', '1', 'medium', 'cancelled', '2026-02-15', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '4');
INSERT INTO `tasks` VALUES ('18', 'Development phase', 'Begin development work on approved designs.', '18', '5', 'low', 'completed', '2026-02-24', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '2');
INSERT INTO `tasks` VALUES ('19', 'Follow-up call', 'Present designs and gather client feedback.', '19', '1', 'medium', 'pending', '2026-02-15', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '4');
INSERT INTO `tasks` VALUES ('20', 'Content creation', 'Deliver final project files and documentation.', '19', '1', 'urgent', 'cancelled', '2026-02-26', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '3');
INSERT INTO `tasks` VALUES ('21', 'Design mockups', 'Deliver final project files and documentation.', '21', '2', 'medium', 'cancelled', '2026-02-19', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '3');
INSERT INTO `tasks` VALUES ('22', 'Payment collection', 'Create content for website and marketing materials.', '21', '4', 'high', 'completed', '2026-02-28', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '1');
INSERT INTO `tasks` VALUES ('23', 'Proposal preparation', 'Prepare comprehensive project proposal and pricing.', '21', '1', 'high', 'cancelled', '2026-02-28', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '1');
INSERT INTO `tasks` VALUES ('24', 'Design mockups', 'Process final payment and close project.', '22', '4', 'urgent', 'pending', '2026-03-12', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '5');
INSERT INTO `tasks` VALUES ('25', 'Content creation', 'Begin development work on approved designs.', '23', '3', 'low', 'cancelled', '2026-03-10', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '4');
INSERT INTO `tasks` VALUES ('26', 'Final delivery', 'Implement SEO best practices and optimization.', '25', '1', 'low', 'pending', '2026-03-07', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '3');
INSERT INTO `tasks` VALUES ('27', 'Initial consultation call', 'Prepare comprehensive project proposal and pricing.', '25', '3', 'high', 'cancelled', '2026-02-18', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '2');
INSERT INTO `tasks` VALUES ('28', 'Final delivery', 'Prepare comprehensive project proposal and pricing.', '25', '3', 'high', 'pending', '2026-03-05', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '3');
INSERT INTO `tasks` VALUES ('29', 'Content creation', 'Process final payment and close project.', '26', '5', 'high', 'cancelled', '2026-02-18', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '2');
INSERT INTO `tasks` VALUES ('30', 'SEO optimization', 'Gather detailed requirements and project specifications.', '28', '5', 'high', 'cancelled', '2026-03-15', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '4');
INSERT INTO `tasks` VALUES ('31', 'Requirements gathering', 'Gather detailed requirements and project specifications.', '28', '2', 'low', 'pending', '2026-03-14', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '3');
INSERT INTO `tasks` VALUES ('32', 'Development phase', 'Review contract terms and obtain signatures.', '28', '4', 'medium', 'in_progress', '2026-02-19', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '5');
INSERT INTO `tasks` VALUES ('33', 'Training session', 'Test functionality and ensure quality standards.', '29', '5', 'medium', 'pending', '2026-03-01', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '2');
INSERT INTO `tasks` VALUES ('34', 'Training session', 'Present designs and gather client feedback.', '30', '4', 'high', 'in_progress', '2026-03-09', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '5');
INSERT INTO `tasks` VALUES ('35', 'Initial consultation call', 'Begin development work on approved designs.', '30', '2', 'high', 'completed', '2026-02-19', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '2');
INSERT INTO `tasks` VALUES ('36', 'Content creation', 'Create initial design concepts and wireframes.', '30', '2', 'low', 'cancelled', '2026-02-20', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '2');
INSERT INTO `tasks` VALUES ('37', 'Follow-up call', 'Implement SEO best practices and optimization.', '31', '1', 'low', 'in_progress', '2026-03-15', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '1');
INSERT INTO `tasks` VALUES ('38', 'Client feedback review', 'Conduct training on new systems and processes.', '32', '5', 'low', 'pending', '2026-02-23', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '5');
INSERT INTO `tasks` VALUES ('39', 'Development phase', 'Conduct training on new systems and processes.', '32', '4', 'medium', 'completed', '2026-03-06', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '5');
INSERT INTO `tasks` VALUES ('40', 'Initial consultation call', 'Process final payment and close project.', '32', '3', 'medium', 'completed', '2026-02-18', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '4');
INSERT INTO `tasks` VALUES ('41', 'Final delivery', 'Set up social media accounts and profiles.', '34', '2', 'low', 'in_progress', '2026-03-13', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '1');
INSERT INTO `tasks` VALUES ('42', 'SEO optimization', 'Implement SEO best practices and optimization.', '34', '2', 'low', 'pending', '2026-02-26', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '4');
INSERT INTO `tasks` VALUES ('44', 'Initial consultation call', 'Process final payment and close project.', '36', '4', 'medium', 'cancelled', '2026-03-06', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '2');
INSERT INTO `tasks` VALUES ('46', 'Proposal preparation', 'Follow up with client to ensure satisfaction.', '36', '4', 'medium', 'pending', '2026-02-20', NULL, '2026-02-13 21:17:03', '2026-02-13 21:17:03', '5');


-- Table structure for table `users`
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `full_name` varchar(150) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(50) DEFAULT 'admin',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table `users`
INSERT INTO `users` VALUES ('2', 'petertmooney', 'Peter Mooney', 'Peter', 'Mooney', '$2y$10$F2nOeZkNMXm1.JNZHRmNc.ovd2EW7uz4CpMhUBOVCTyIX4n/3aAl2', 'petertmooney@outlook.com', 'superadmin', '2026-02-08 02:11:34');
INSERT INTO `users` VALUES ('3', 'admin', 'System Admin', 'System', 'Admin', '$2y$10$6L/AgcYABix87BN.JxEogekX6W1IvuddEo6R8/71r8jbXuMgAYbbi', 'admin@contentcatalogz.com', 'admin', '2026-02-08 03:39:18');
INSERT INTO `users` VALUES ('4', 'catborsan', 'Cat Borsoan', 'Cat', 'Borsoan', '$2y$10$FoyLlxzy.QCNlBkYA8z2DOyplvlw/6TbvF6P4MXF/hO7H8./NobNa', 'ecaterina.borsan@yahoo.co.uk', 'admin', '2026-02-09 21:42:04');

SET FOREIGN_KEY_CHECKS=1;
