# Content Catalogz Export Package
Export Date: 2026-02-14 00:02:45

## Contents
- database.sql: Complete database dump
- website/: All website files
- EXPORT_INFO.json: Export metadata
- README.txt: This file

## Installation Instructions

### 1. Upload Files
Upload the contents of the 'website' folder to your web server's public directory

### 2. Create Database
Create a new MySQL database and note the credentials

### 3. Import Database
Import database.sql using phpMyAdmin or command line:
mysql -u username -p database_name < database.sql

### 4. Update Configuration
Edit admin/config/db.php with your database credentials

### 5. Set Permissions
Set proper file permissions (755 for directories, 644 for files)

### 6. Test Your Site
Visit your domain to verify everything works
